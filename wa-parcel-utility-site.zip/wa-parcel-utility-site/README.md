# Washington Parcel Utility Finder

Static browser application for preliminary parcel, well, and public power-infrastructure screening in Washington State.

## Run locally

```bash
python -m http.server 8000
```

Then open http://localhost:8000

## Deploy

This folder can be deployed directly to Netlify, Cloudflare Pages, GitHub Pages, or any static web host. No build command is required. The publish directory is the project root.

## Important

Results are preliminary. Confirm wells, electric utility service, capacity, transformer needs, easements, and extension prices with the relevant agencies and utility.
